import colors from 'tailwindcss/colors';

const ui = (n) => `rgb(var(--ui-${n}) / <alpha-value>)`;

/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Roboto', 'sans-serif'] },
      colors: { blue: { ...colors.blue, 400: ui(400), 500: ui(500), 600: ui(600) } },
      borderRadius: {
        lg: 'calc(0.5rem * var(--radius-scale, 1))',
        xl: 'calc(0.75rem * var(--radius-scale, 1))',
        '2xl': 'min(calc(1rem * var(--radius-scale, 1)), 32px)',
        '3xl': 'min(calc(1.5rem * var(--radius-scale, 1)), 44px)',
      },
      boxShadow: {
        paper: '0 2px 4px rgba(0,0,0,.06), 0 12px 32px rgba(0,0,0,.14), 0 32px 64px rgba(0,0,0,.12)',
      },
      keyframes: { pop: { '0%': { opacity: 0, transform: 'scale(.96) translateY(-4px)' }, '100%': { opacity: 1, transform: 'none' } } },
      animation: { pop: 'pop .14s ease-out' },
    },
  },
  plugins: [],
};
