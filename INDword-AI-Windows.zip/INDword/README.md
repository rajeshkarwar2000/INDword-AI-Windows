# INDword
Word-style document app for Android tablets. Documents are stored on the device (IndexedDB) and work offline.
GitHub is used only to hold this source and to build the APK remotely.

## AI Notes
Add article images (Home card or Notes tab > From Images). Works through copy-paste with Gemini (no API key). Generated PYQ labels must be verified.

## Notes pages
Notes documents use a real paged layout (Notes tab > Notes Page): A4 cards with gaps, dashed border, header, footer, page numbers and the indIAS logo background. Text fills column 1, then column 2, then the next page. PDF export renders page by page.

## Save to…
Export (PDF, Word, etc.) opens Android's own "Save to" window so you choose the folder. The small native plugin is copied in automatically by the `capacitor:*:after` scripts in package.json (see scripts-native.cjs and resources/native). If it is missing, the app falls back to the share sheet.

## Windows (HP Victus / any Windows 10-11 laptop)
The same app runs on Windows through the `desktop/` folder (a small Electron wrapper). The app's own code is unchanged.
GitHub builds it with `.github/workflows/build-windows.yml` (copy this file into the repo's `.github/workflows/` folder at the repo root).
Run "Build INDword AI Windows" in the Actions tab and download `INDword-AI-Windows` (installer `INDword-AI-Windows-Setup.exe` and `INDword-AI-Windows-Portable.exe`).
Documents are stored on the laptop inside the app (same as the tablet). Exports (PDF, Word, ...) open the normal Windows "Save as" window.
