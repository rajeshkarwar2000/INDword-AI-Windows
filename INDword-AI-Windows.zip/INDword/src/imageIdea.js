import { Extension } from '@tiptap/core';
import { Plugin } from '@tiptap/pm/state';
import { fileToJpeg } from './services/aiNotes.js';

/** Tap an "image idea" box, choose a picture: the box (and its prompt) is replaced by the picture and its caption. */
export const ImageIdea = Extension.create({
  name: 'imageIdea',
  addProseMirrorPlugins() {
    return [new Plugin({
      props: {
        handleClickOn(view, pos, node, nodePos) {
          if (node.type.name !== 'callout' || node.attrs.type !== 'imgidea') return false;
          const input = document.createElement('input');
          input.type = 'file'; input.accept = 'image/*';
          input.onchange = async () => {
            const f = input.files && input.files[0]; if (!f) return;
            try {
              const img = await fileToJpeg(f);
              const { state } = view; const cur = state.doc.nodeAt(nodePos);
              if (!cur || cur.type.name !== 'callout' || cur.attrs.type !== 'imgidea') return;
              const w = view.dom.closest('.paged-stage') ? 339 : 460;
              const sch = state.schema; const caption = cur.childCount > 1 ? cur.child(1).textContent : '';
              const para = sch.nodes.paragraph.create({ borders: 'border:1.5px solid #000000;line-height:0' }, sch.nodes.image.create({ src: img.url, width: `${w}px` }));
              const out = [para];
              if (caption) out.push(sch.nodes.paragraph.create(null, sch.text(caption, sch.marks.italic ? [sch.marks.italic.create()] : [])));
              view.dispatch(state.tr.replaceWith(nodePos, nodePos + cur.nodeSize, out));
            } catch (e) { /* ignore */ }
          };
          input.click();
          return true;
        },
      },
    })];
  },
});
