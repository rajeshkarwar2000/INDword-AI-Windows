import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { Modal, Field } from './Dialogs.jsx';
import { PAGE_SIZES } from '../constants.js';
import { uid } from '../services/store.js';

const Row = ({ children }) => <div className="mt-3 flex gap-2">{children}</div>;
const Actions = ({ onClose, onOk, ok = 'Apply', disabled }) => (
  <Row><button type="button" className="secondary flex-1" onClick={onClose}>Cancel</button><button type="button" className="primary flex-1" disabled={disabled} onClick={onOk}>{ok}</button></Row>
);
const Num = ({ label, value, onChange, min = 0, max = 999, step = 1 }) => (
  <Field label={label}><input type="number" className="ginput" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} /></Field>
);

export function SaveAsDialog({ name, folder, folders, onSave, onClose }) {
  const [n, setN] = useState(name); const [f, setF] = useState(folder || ''); const [type, setType] = useState('indword'); const [dev, setDev] = useState(false);
  return (
    <Modal title="Save As" onClose={onClose}>
      <Field label="File name"><input className="ginput" value={n} onChange={(e) => setN(e.target.value)} /></Field>
      <Field label="Folder"><select className="ginput" value={f} onChange={(e) => setF(e.target.value)}><option value="">INDword Documents</option>{folders.map((x) => <option key={x}>{x}</option>)}</select></Field>
      <Field label="File type">
        <select className="ginput" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="indword">INDword document (editable)</option><option value="docx">Word (.docx)</option><option value="pdf">PDF (.pdf)</option>
          <option value="md">Markdown (.md)</option><option value="html">HTML (.html)</option><option value="txt">Plain text (.txt)</option>
        </select>
      </Field>
      <label className="flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={dev || type !== 'indword'} disabled={type !== 'indword'} onChange={(e) => setDev(e.target.checked)} /> Also save a copy to this tablet (Documents/INDword)</label>
      <Actions onClose={onClose} ok="Save" disabled={!n.trim()} onOk={() => onSave({ name: n.trim(), folder: f, type, device: dev || type !== 'indword' })} />
    </Modal>
  );
}

export function PropertiesDialog({ doc, meta, size, onSave, onClose }) {
  const [m, setM] = useState({ author: meta.author, subject: meta.subject, keywords: meta.keywords, title: meta.title || doc.name });
  const d = (t) => new Date(t).toLocaleString();
  return (
    <Modal title="Document Properties" onClose={onClose}>
      <Field label="Title"><input className="ginput" value={m.title} onChange={(e) => setM({ ...m, title: e.target.value })} /></Field>
      <Field label="Author"><input className="ginput" value={m.author} onChange={(e) => setM({ ...m, author: e.target.value })} /></Field>
      <Field label="Subject"><input className="ginput" value={m.subject} onChange={(e) => setM({ ...m, subject: e.target.value })} /></Field>
      <Field label="Keywords"><input className="ginput" value={m.keywords} onChange={(e) => setM({ ...m, keywords: e.target.value })} /></Field>
      <div className="mb-2 space-y-1 text-xs opacity-70">
        <div>File name: {doc.name}.{doc.ext}</div><div>Location: INDword Documents{doc.folder ? ` › ${doc.folder}` : ''}</div>
        <div>Created: {d(doc.created)}</div><div>Modified: {d(doc.modified)}</div><div>Size: {size}</div>
      </div>
      <Actions onClose={onClose} ok="Save" onOk={() => onSave(m)} />
    </Modal>
  );
}

const UNITS = { cm: 37.8, in: 96, px: 1 };
export function MarginsDialog({ margins, onApply, onClose }) {
  const [m, setM] = useState(margins);
  const [unit, setUnit] = useState('cm');
  const [link, setLink] = useState(false);
  const f = UNITS[unit];
  const show = (v) => Math.round((v / f) * 100) / 100;
  const set = (k) => (v) => { const px = Math.max(0, Math.round(v * f)); setM(link ? { top: px, right: px, bottom: px, left: px } : { ...m, [k]: px }); };
  const pw = 120; const ph = 160; const sx = pw / 794; const sy = ph / 1123;
  return (
    <Modal title="Page Margins" onClose={onClose}>
      <div className="mb-3 flex items-center gap-4">
        <div className="relative shrink-0 rounded bg-white shadow" style={{ width: pw, height: ph }}>
          <div className="absolute border border-dashed border-blue-500 bg-blue-500/10" style={{ left: m.left * sx, right: m.right * sx, top: m.top * sy, bottom: m.bottom * sy }} />
        </div>
        <div className="flex-1">
          <Field label="Units"><select className="ginput" value={unit} onChange={(e) => setUnit(e.target.value)}><option value="cm">Centimetres</option><option value="in">Inches</option><option value="px">Pixels</option></select></Field>
          <label className="flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={link} onChange={(e) => setLink(e.target.checked)} /> Same on all sides</label>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {['top', 'bottom', 'left', 'right'].map((k) => <Num key={k} label={k[0].toUpperCase() + k.slice(1)} value={show(m[k])} step={unit === 'px' ? 4 : 0.1} max={unit === 'px' ? 400 : 12} onChange={set(k)} />)}
      </div>
      <Actions onClose={onClose} onOk={() => onApply(m)} />
    </Modal>
  );
}

export function MarginBorderDialog({ value, onApply, onClose }) {
  const [b, setB] = useState(value);
  return (
    <Modal title="Margin Border" onClose={onClose}>
      <p className="mb-3 text-sm opacity-70">Draws a border around the text area of every page, inside the margins. It is included in PDF exports.</p>
      <Field label="Style"><select className="ginput" value={b.style} onChange={(e) => setB({ ...b, style: e.target.value })}>{['none', 'solid', 'dashed', 'dotted', 'double'].map((s) => <option key={s}>{s}</option>)}</select></Field>
      <div className="grid grid-cols-3 gap-3">
        <Num label="Width (px)" value={b.width} min={1} max={12} onChange={(x) => setB({ ...b, width: x })} />
        <Num label="Gap to text (px)" value={b.gap} min={0} max={60} onChange={(x) => setB({ ...b, gap: x })} />
        <Field label="Colour"><input type="color" className="ginput !p-1" value={b.color} onChange={(e) => setB({ ...b, color: e.target.value })} /></Field>
      </div>
      <Actions onClose={onClose} onOk={() => onApply(b)} />
    </Modal>
  );
}

export function ParagraphDialog({ initial, onApply, onClose }) {
  const [v, setV] = useState(initial);
  return (
    <Modal title="Paragraph" onClose={onClose}>
      <div className="grid grid-cols-2 gap-3">
        <Num label="Left indent (px)" value={v.left} max={400} onChange={(x) => setV({ ...v, left: x })} />
        <Num label="Right indent (px)" value={v.right} max={400} onChange={(x) => setV({ ...v, right: x })} />
        <Num label="Spacing before (px)" value={v.before} max={200} onChange={(x) => setV({ ...v, before: x })} />
        <Num label="Spacing after (px)" value={v.after} max={200} onChange={(x) => setV({ ...v, after: x })} />
        <Num label="Line spacing" value={v.line} min={0.8} max={5} step={0.05} onChange={(x) => setV({ ...v, line: x })} />
      </div>
      <Actions onClose={onClose} onOk={() => onApply(v)} />
    </Modal>
  );
}

export function HeaderFooterDialog({ meta, onApply, onClose }) {
  const [h, setH] = useState(meta.header); const [f, setF] = useState(meta.footer); const [p, setP] = useState(meta.pageNumbers);
  return (
    <Modal title="Header & Footer" onClose={onClose}>
      <Field label="Header text"><input className="ginput" value={h} onChange={(e) => setH(e.target.value)} /></Field>
      <Field label="Footer text"><input className="ginput" value={f} onChange={(e) => setF(e.target.value)} /></Field>
      <label className="flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={p} onChange={(e) => setP(e.target.checked)} /> Show page numbers in the footer</label>
      <Actions onClose={onClose} onOk={() => onApply({ header: h, footer: f, pageNumbers: p })} />
    </Modal>
  );
}

export function WatermarkDialog({ value, onApply, onClose }) {
  const [t, setT] = useState(value.text); const [o, setO] = useState(value.opacity);
  return (
    <Modal title="Custom Watermark" onClose={onClose}>
      <Field label="Text"><input className="ginput" value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <label className="flex min-h-[44px] items-center gap-3 text-sm"><span className="w-20">Opacity</span><input type="range" min="0.05" max="0.6" step="0.05" value={o} onChange={(e) => setO(+e.target.value)} className="flex-1 accent-blue-500" /><span className="w-10">{Math.round(o * 100)}%</span></label>
      <Actions onClose={onClose} onOk={() => onApply({ text: t, opacity: o })} />
    </Modal>
  );
}

export function BorderDialog({ value, onApply, onClose }) {
  const [b, setB] = useState(value);
  return (
    <Modal title="Page Border" onClose={onClose}>
      <Field label="Style"><select className="ginput" value={b.style} onChange={(e) => setB({ ...b, style: e.target.value })}>{['none', 'solid', 'dashed', 'dotted', 'double'].map((s) => <option key={s}>{s}</option>)}</select></Field>
      <div className="grid grid-cols-2 gap-3">
        <Num label="Width (px)" value={b.width} min={1} max={20} onChange={(x) => setB({ ...b, width: x })} />
        <Field label="Colour"><input type="color" className="ginput !p-1" value={b.color} onChange={(e) => setB({ ...b, color: e.target.value })} /></Field>
      </div>
      <label className="flex min-h-[44px] items-center gap-2 text-sm"><input type="checkbox" className="h-5 w-5" checked={!!b.shadow} onChange={(e) => setB({ ...b, shadow: e.target.checked })} /> Drop shadow</label>
      <Actions onClose={onClose} onOk={() => onApply(b)} />
    </Modal>
  );
}

export function TocDialog({ onApply, onClose }) {
  const [lv, setLv] = useState(3);
  return (
    <Modal title="Table of Contents" onClose={onClose}>
      <Field label="Show levels"><select className="ginput" value={lv} onChange={(e) => setLv(+e.target.value)}>{[1, 2, 3, 4].map((n) => <option key={n} value={n}>{n}</option>)}</select></Field>
      <Actions onClose={onClose} ok="Insert" onOk={() => onApply(lv)} />
    </Modal>
  );
}

export function SourcesDialog({ sources, style, onChange, onStyle, onClose }) {
  const blank = { id: '', author: '', title: '', year: '', publisher: '', url: '' };
  const [edit, setEdit] = useState(null);
  const save = () => {
    const s = edit.id ? edit : { ...edit, id: uid() };
    onChange(sources.some((x) => x.id === s.id) ? sources.map((x) => (x.id === s.id ? s : x)) : [...sources, s]);
    setEdit(null);
  };
  return (
    <Modal title="Manage Sources" onClose={onClose} wide>
      <Field label="Citation style"><select className="ginput" value={style} onChange={(e) => onStyle(e.target.value)}>{['APA', 'MLA', 'Chicago', 'Harvard', 'IEEE'].map((s) => <option key={s}>{s}</option>)}</select></Field>
      {edit ? (
        <>
          {[['author', 'Author (Last, First)'], ['title', 'Title'], ['year', 'Year'], ['publisher', 'Publisher / Journal'], ['url', 'URL (optional)']].map(([k, l]) => (
            <Field key={k} label={l}><input className="ginput" value={edit[k]} onChange={(e) => setEdit({ ...edit, [k]: e.target.value })} /></Field>
          ))}
          <Actions onClose={() => setEdit(null)} ok="Save Source" disabled={!edit.author || !edit.title} onOk={save} />
        </>
      ) : (
        <>
          {!sources.length && <p className="mb-3 text-sm opacity-70">No sources yet.</p>}
          {sources.map((s) => (
            <div key={s.id} className="mb-2 flex items-center gap-2 rounded-2xl bg-black/5 p-3 dark:bg-white/10">
              <div className="min-w-0 flex-1 text-sm"><div className="truncate font-medium">{s.title}</div><div className="truncate text-xs opacity-60">{s.author} · {s.year}</div></div>
              <button type="button" className="secondary !px-3" onClick={() => setEdit(s)}>Edit</button>
              <button type="button" className="rbtn text-red-500" aria-label="Delete source" onClick={() => onChange(sources.filter((x) => x.id !== s.id))}><Trash2 size={18} /></button>
            </div>
          ))}
          <button type="button" className="primary mt-2 w-full" onClick={() => setEdit(blank)}>Add New Source</button>
        </>
      )}
    </Modal>
  );
}

export function PrintDialog({ meta, onMeta, onPrint, onClose }) {
  return (
    <Modal title="Print" onClose={onClose}>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Orientation"><select className="ginput" value={meta.orientation} onChange={(e) => onMeta({ orientation: e.target.value })}><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></Field>
        <Field label="Paper size"><select className="ginput" value={meta.size} onChange={(e) => onMeta({ size: e.target.value })}>{Object.keys(PAGE_SIZES).map((s) => <option key={s}>{s}</option>)}</select></Field>
      </div>
      <p className="mb-2 text-sm opacity-70">INDword makes a PDF of the whole document and opens the Android share sheet. Choose <b>Print</b> there to pick a printer, page range and number of copies.</p>
      <Actions onClose={onClose} ok="Create PDF & Print" onOk={onPrint} />
    </Modal>
  );
}

export function MoveDialog({ folders, current, onMove, onClose }) {
  return (
    <Modal title="Move to Folder" onClose={onClose}>
      {['', ...folders].map((f) => (
        <button key={f || 'root'} type="button" className={`mitem ${f === current ? 'rbtn-on' : ''}`} onClick={() => onMove(f)}>{f || 'INDword Documents (no folder)'}</button>
      ))}
    </Modal>
  );
}

export function InfoDialog({ doc, size, onClose }) {
  const d = (t) => new Date(t).toLocaleString();
  return (
    <Modal title="Document Information" onClose={onClose}>
      <div className="space-y-1.5 text-sm">
        <div><b>Name:</b> {doc.name}.{doc.ext}</div><div><b>Location:</b> INDword Documents{doc.folder ? ` › ${doc.folder}` : ''}</div>
        <div><b>Created:</b> {d(doc.created)}</div><div><b>Modified:</b> {d(doc.modified)}</div><div><b>Size:</b> {size}</div>
        <div><b>Author:</b> {doc.meta?.author || '—'}</div>
      </div>
    </Modal>
  );
}
