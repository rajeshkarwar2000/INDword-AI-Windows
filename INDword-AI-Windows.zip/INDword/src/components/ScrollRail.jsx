import { useEffect, useRef, useState, useCallback } from 'react';

/** Always-visible, touch-friendly vertical scrollbar with a "Page n of N" bubble while dragging. */
export default function ScrollRail({ targetRef, page, pages, resetKey }) {
  const [m, setM] = useState({ top: 0, size: 0, show: false });
  const [drag, setDrag] = useState(false);
  const rail = useRef(null);

  const measure = useCallback(() => {
    const el = targetRef.current; const r = rail.current;
    if (!el || !r) return;
    const track = r.clientHeight;
    if (el.scrollHeight <= el.clientHeight + 2) { setM({ top: 0, size: 0, show: false }); return; }
    const size = Math.max(52, (el.clientHeight / el.scrollHeight) * track);
    const top = (el.scrollTop / (el.scrollHeight - el.clientHeight)) * (track - size);
    setM({ top, size, show: true });
  }, [targetRef]);

  useEffect(() => {
    const el = targetRef.current; if (!el) return undefined;
    measure();
    el.addEventListener('scroll', measure, { passive: true });
    const ro = new ResizeObserver(measure);
    ro.observe(el); if (el.firstElementChild) ro.observe(el.firstElementChild);
    return () => { el.removeEventListener('scroll', measure); ro.disconnect(); };
  }, [targetRef, measure, resetKey]);

  const scrollToY = (clientY, grabOffset = m.size / 2) => {
    const el = targetRef.current; const r = rail.current.getBoundingClientRect();
    const track = r.height - m.size;
    const t = Math.min(1, Math.max(0, (clientY - r.top - grabOffset) / track));
    el.scrollTop = t * (el.scrollHeight - el.clientHeight);
  };
  const down = (e) => {
    e.preventDefault();
    const r = rail.current.getBoundingClientRect();
    const onThumb = e.clientY >= r.top + m.top && e.clientY <= r.top + m.top + m.size;
    const off = onThumb ? e.clientY - (r.top + m.top) : m.size / 2;
    setDrag(true); scrollToY(e.clientY, off);
    const t = e.currentTarget; t.setPointerCapture(e.pointerId);
    const move = (ev) => scrollToY(ev.clientY, off);
    const up = () => { setDrag(false); t.removeEventListener('pointermove', move); t.removeEventListener('pointerup', up); };
    t.addEventListener('pointermove', move); t.addEventListener('pointerup', up);
  };

  return (
    <div ref={rail} className="rail no-print" style={{ display: m.show ? 'block' : 'none' }} onPointerDown={down} aria-hidden="true">
      <div className="rail-track" />
      <div className="rail-thumb" style={{ top: m.top, height: m.size, left: 'calc(50% - var(--sb) / 2)', width: 'var(--sb)', right: 'auto' }}>
        {(drag) && <div className="glass rail-bubble rounded-full px-3 py-1.5 text-xs font-semibold" style={{ top: m.size / 2 }}>Page {page} of {pages}</div>}
      </div>
    </div>
  );
}
