import { useState } from 'react';
import {
  Image as ImageIcon, Table2, Plus, Minus, Link2, Info, MessageSquare, FileText, Hash, Calendar, Omega, Shapes, PanelTop,
  PanelBottom, Type, FilePlus, SeparatorHorizontal, AlignCenter, PanelLeft, PanelRight, RotateCcw, RotateCw, Trash2, Download, Lock, Unlock, Undo2, Move, AlignLeft, AlignRight, ArrowUp, ArrowDown, Copy, Bold,
  Palette, Droplets, Frame, LayoutGrid, RectangleHorizontal, Ruler, TextCursor,
} from 'lucide-react';
import { Btn, Group, Item, Sep, Menu, ColorMenu } from './ui.jsx';
import { THEMES, ACCENTS, FONT_SET_LABELS, PAGE_BGS, PAGE_SIZES, MARGIN_PRESETS } from '../constants.js';
import { SHAPES, shapeUrl } from '../services/shapes.js';
import { SHAPE_PRESETS, SHAPE_KINDS, SHAPE_DEFAULTS, previewStyle, insertShape, findShape, setShape, moveShape, duplicateShape, deleteShape } from '../shapeBox.js';
import { rotateDataUrl } from '../components/ImageView.jsx';
import { saveBlob } from '../services/exporters.js';

const luminance = (hex) => { const n = parseInt(hex.slice(1), 16); return (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255; };
const textFor = (bg) => (luminance(bg) > 0.5 ? '#111111' : '#e5e7eb');

/* ======================= INSERT ======================= */
export function InsertTab({ c }) {
  const { editor, meta, setMeta, dlg } = c;
  const ch = () => editor.chain().focus();
  const [grid, setGrid] = useState({ r: 0, c: 0 });
  const TOOLS = [['Insert column before', 'addColumnBefore'], ['Insert column after', 'addColumnAfter'], ['Delete column', 'deleteColumn'], ['Insert row above', 'addRowBefore'], ['Insert row below', 'addRowAfter'], ['Delete row', 'deleteRow'], ['Merge cells', 'mergeCells'], ['Split cell', 'splitCell'], ['Toggle header row', 'toggleHeaderRow'], ['Delete table', 'deleteTable']];
  const pb = { type: 'pageBreak' };
  const cover = `<p class="ps-title" style="text-align:center;margin-top:200px">Document Title</p><p class="ps-subtitle" style="text-align:center">Subtitle</p><p style="text-align:center">${meta.author || 'Author name'} · ${new Date().toLocaleDateString()}</p>`;
  return (
    <>
      <Group title="Pages">
        <Btn icon={FilePlus} label="Cover Page" onClick={() => editor.chain().focus('start').insertContent(cover).insertContent(pb).run()} />
        <Btn icon={FileText} label="Blank Page" onClick={() => ch().insertContent([pb, { type: 'paragraph' }]).run()} />
        <Btn icon={SeparatorHorizontal} label="Page Break" onClick={() => ch().insertContent([pb, { type: 'paragraph' }]).run()} />
        <Btn icon={SeparatorHorizontal} label="Section Break" onClick={() => ch().insertContent([pb, { type: 'paragraph' }]).run()} />
      </Group>
      <Group title="Tables">
        <Menu width={272} trigger={() => <Btn icon={Table2} label="Table" caret />}>
          {(close) => (
            <div className="p-2">
              <div className="mb-2 text-center text-sm font-medium">{grid.r && grid.c ? `${grid.c} × ${grid.r}` : 'Select table size'}</div>
              <div className="grid grid-cols-8 gap-1" onPointerLeave={() => setGrid({ r: 0, c: 0 })}>
                {Array.from({ length: 64 }, (_, i) => {
                  const r = Math.floor(i / 8) + 1; const col = (i % 8) + 1; const hot = r <= grid.r && col <= grid.c;
                  return <button key={i} type="button" aria-label={`${col} by ${r}`} onPointerEnter={() => setGrid({ r, c: col })} onPointerDown={() => setGrid({ r, c: col })}
                    onClick={() => { ch().insertTable({ rows: r, cols: col, withHeaderRow: true }).run(); setGrid({ r: 0, c: 0 }); close(); }}
                    className={`h-7 w-7 rounded-md border ${hot ? 'border-blue-500 bg-blue-500/40' : 'border-black/15 bg-white/50 dark:border-white/15 dark:bg-white/5'}`} />;
                })}
              </div>
              <Item onClick={() => { dlg('table'); close(); }}>Custom table…</Item>
            </div>
          )}
        </Menu>
        <Menu width={240} trigger={() => <Btn icon={Plus} label="Table tools" disabled={!editor.isActive('table')} caret />}>
          {(close) => TOOLS.map(([n, cmd]) => <Item key={cmd} onClick={() => { ch()[cmd]().run(); close(); }}>{n}</Item>)}
        </Menu>
      </Group>
      <Group title="Illustrations">
        <Btn icon={ImageIcon} label="Image" onClick={() => dlg('image')} />
        <Menu width={370} trigger={() => <Btn icon={Shapes} label="Shapes" caret />}>
          {(close) => (<>
            <Sep>Text shapes: type inside them</Sep>
            <div className="grid grid-cols-3 gap-1.5 p-1">
              {SHAPE_PRESETS.map((p) => (
                <button key={p.id} type="button" onClick={() => { insertShape(editor, p); close(); }} className="rounded-xl p-1.5 text-center active:scale-95 hover:bg-black/5 dark:hover:bg-white/10">
                  <div style={previewStyle(p.attrs)}>Abc</div>
                  <span className="mt-1 block truncate text-[11px] opacity-80">{p.label}</span>
                </button>
              ))}
            </div>
            <Sep>Lines, arrows and picture shapes</Sep>
            {SHAPES.map(([n, fn]) => <Item key={n} onClick={() => { editor.chain().setImage({ src: shapeUrl(fn), alt: n }).run(); editor.view.dom.blur(); close(); }}>{n}</Item>)}
          </>)}
        </Menu>
        <Btn icon={Omega} label="Symbols" onClick={() => dlg('symbols')} />
      </Group>
      <Group title="Links">
        <Btn icon={Link2} label="Link" on={editor.isActive('link')} onClick={() => dlg('link')} />
        <Btn icon={Minus} label="Rule" onClick={() => ch().setHorizontalRule().run()} />
      </Group>
      <Group title="Header & Footer">
        <Btn icon={PanelTop} label="Header" onClick={() => dlg('hf')} />
        <Btn icon={PanelBottom} label="Footer" onClick={() => dlg('hf')} />
        <Btn icon={Hash} label="Page No." on={meta.pageNumbers} onClick={() => setMeta({ pageNumbers: !meta.pageNumbers })} />
      </Group>
      <Group title="Text">
        <Btn icon={Type} label="Text Box" onClick={() => insertShape(editor, SHAPE_PRESETS.find((p) => p.id === 'outline'))} />
        <Btn icon={Calendar} label="Date & Time" onClick={() => ch().insertContent(new Date().toLocaleString()).run()} />
        <Btn icon={Type} label="Drop Cap" onClick={() => { const on = editor.getAttributes('paragraph').pstyle === 'dropcap'; ch().updateAttributes('paragraph', { pstyle: on ? null : 'dropcap' }).run(); }} />
        <Btn icon={TextCursor} label="Signature" onClick={() => ch().insertContent('<p>______________________________<br>Signature</p>').run()} />
        <Menu width={210} trigger={() => <Btn icon={Info} label="Callout" caret />}>
          {(close) => ['info', 'warning', 'alert', 'success', 'tip', 'note'].map((t) => (
            <Item key={t} on={editor.isActive('callout', { type: t })} onClick={() => { if (editor.isActive('callout')) ch().lift('callout').run(); else ch().setCallout(t).run(); close(); }}>{t[0].toUpperCase() + t.slice(1)}</Item>
          ))}
        </Menu>
      </Group>
    </>
  );
}

/* ======================= DESIGN ======================= */
export function DesignTab({ c }) {
  const { meta, setMeta, dlg } = c;
  const applyTheme = (k) => { const t = THEMES[k]; setMeta({ theme: k, fontSet: t.font, bg: t.bg, textColor: t.color, accent: t.accent }); };
  return (
    <>
      <Group title="Document Formatting">
        <Menu width={230} trigger={() => <Btn icon={Palette} label="Themes" caret />}>
          {(close) => Object.entries(THEMES).map(([k, t]) => <Item key={k} on={meta.theme === k} onClick={() => { applyTheme(k); close(); }}>{t.label}</Item>)}
        </Menu>
        <Menu width={220} trigger={() => <Btn icon={Palette} label="Colours" caret />}>
          {(close) => ACCENTS.map(([n, col]) => <Item key={n} on={meta.accent === col} onClick={() => { setMeta({ accent: col }); close(); }}><span className="mr-2 inline-block h-4 w-4 rounded-full align-middle" style={{ background: col }} />{n}</Item>)}
        </Menu>
        <Menu width={200} trigger={() => <Btn icon={Type} label="Fonts" caret />}>
          {(close) => Object.entries(FONT_SET_LABELS).map(([k, n]) => <Item key={k} on={meta.fontSet === k} onClick={() => { setMeta({ fontSet: k }); close(); }}>{n}</Item>)}
        </Menu>
      </Group>
      <Group title="Page Background">
        <Menu width={316} trigger={() => <Btn icon={Palette} label="Page Colour" caret />}>
          {(close) => (<>
            {PAGE_BGS.map(([n, bg, tc]) => <Item key={n} on={meta.bg === bg} onClick={() => { setMeta({ bg, textColor: tc }); close(); }}><span className="mr-2 inline-block h-4 w-4 rounded-full border align-middle" style={{ background: bg }} />{n}</Item>)}
            <label className="mitem">Custom colour<input type="color" aria-label="Custom page colour" className="ml-auto h-9 w-12 rounded-lg border-0 bg-transparent" onChange={(e) => setMeta({ bg: e.target.value, textColor: textFor(e.target.value) })} /></label>
          </>)}
        </Menu>
        <Menu width={240} trigger={() => <Btn icon={Droplets} label="Watermark" caret />}>
          {(close) => (<>
            {['CONFIDENTIAL', 'DRAFT', 'DO NOT COPY'].map((t) => <Item key={t} on={meta.watermark.text === t} onClick={() => { setMeta({ watermark: { ...meta.watermark, text: t } }); close(); }}>{t[0] + t.slice(1).toLowerCase()}</Item>)}
            <Item onClick={() => { dlg('watermark'); close(); }}>Custom text, position & opacity…</Item>
            <Item onClick={() => { setMeta({ watermark: { ...meta.watermark, text: '', image: '' } }); close(); }}>Remove Watermark</Item>
          </>)}
        </Menu>
        <Menu width={230} trigger={() => <Btn icon={Frame} label="Page Borders" caret />}>
          {(close) => (<>
            <Item onClick={() => { setMeta({ border: { ...meta.border, style: 'none', shadow: false } }); close(); }}>None</Item>
            <Item onClick={() => { setMeta({ border: { ...meta.border, style: 'solid', width: 2, shadow: false } }); close(); }}>Box</Item>
            <Item onClick={() => { setMeta({ border: { ...meta.border, style: 'solid', width: 1, shadow: true } }); close(); }}>Shadow</Item>
            <Item onClick={() => { setMeta({ border: { ...meta.border, style: 'double', width: 4, shadow: false } }); close(); }}>Standard (double)</Item>
            <Item onClick={() => { dlg('border'); close(); }}>Custom…</Item>
          </>)}
        </Menu>
      </Group>
    </>
  );
}

/* ======================= LAYOUT ======================= */
export function LayoutTab({ c }) {
  const { editor, meta, setMeta, dlg, flash } = c;
  const ch = () => editor.chain().focus();
  const marg = (t, r, b, l) => setMeta({ margins: { top: t, right: r, bottom: b, left: l } });
  return (
    <>
      <Group title="Page Setup">
        <Menu width={270} trigger={() => <Btn icon={Ruler} label="Margins" caret />}>
          {(close) => (<>
            {Object.entries(MARGIN_PRESETS).map(([k, p]) => <Item key={k} on={JSON.stringify(meta.margins) === JSON.stringify(p.m)} onClick={() => { setMeta({ margins: p.m }); close(); }}>{p.label}</Item>)}
            <Item onClick={() => { dlg('margins'); close(); }}>Custom Margins…</Item>
          </>)}
        </Menu>
        <Menu width={240} trigger={() => <Btn icon={Frame} label="Margin Border" caret />}>
          {(close) => (<>
            {[['None', { style: 'none' }], ['Thin box', { style: 'solid', width: 1 }], ['Thick box', { style: 'solid', width: 3 }], ['Double', { style: 'double', width: 2 }], ['Dashed', { style: 'dashed', width: 1 }], ['Dotted', { style: 'dotted', width: 2 }]].map(([n, v]) => (
              <Item key={n} on={meta.marginBorder.style === v.style && (v.style === 'none' || meta.marginBorder.width === v.width)} onClick={() => { setMeta({ marginBorder: { ...meta.marginBorder, ...v } }); close(); }}>{n}</Item>
            ))}
            <Item onClick={() => { dlg('marginborder'); close(); }}>Custom…</Item>
          </>)}
        </Menu>
        <Btn icon={RectangleHorizontal} label="Boundaries" on={c.view.boundaries} title="Show text boundaries" onClick={() => c.view.setBoundaries(!c.view.boundaries)} />
        <Menu width={180} trigger={() => <Btn icon={RectangleHorizontal} label="Orientation" caret />}>
          {(close) => ['portrait', 'landscape'].map((o) => <Item key={o} on={meta.orientation === o} onClick={() => { setMeta({ orientation: o }); close(); }}>{o[0].toUpperCase() + o.slice(1)}</Item>)}
        </Menu>
        <Menu width={200} trigger={() => <Btn icon={FileText} label={meta.size} caret />}>
          {(close) => Object.keys(PAGE_SIZES).map((s) => <Item key={s} on={meta.size === s} onClick={() => { setMeta({ size: s }); close(); }}>{s}</Item>)}
        </Menu>
        <Menu width={200} trigger={() => <Btn icon={LayoutGrid} label="Columns" caret />}>
          {(close) => (<>
            {[['One', 1], ['Two', 2], ['Three', 3], ['Four', 4]].map(([n, v]) => <Item key={n} on={meta.columns === v} onClick={() => { setMeta({ columns: v }); close(); }}>{n}</Item>)}
          </>)}
        </Menu>
        <Menu width={220} trigger={() => <Btn icon={SeparatorHorizontal} label="Breaks" caret />}>
          {(close) => (<>
            <Item onClick={() => { ch().insertContent([{ type: 'pageBreak' }, { type: 'paragraph' }]).run(); close(); }}>Page Break</Item>
            <Item onClick={() => { if (meta.columns < 2) flash('Set two or more columns first'); ch().insertContent([{ type: 'columnBreak' }, { type: 'paragraph' }]).run(); close(); }}>Column Break</Item>
            <Item onClick={() => { ch().insertContent([{ type: 'pageBreak' }, { type: 'paragraph' }]).run(); close(); }}>Section Break (next page)</Item>
          </>)}
        </Menu>
      </Group>
      <Group title="Paragraph">
        <Btn icon={AlignCenter} label="Indent & Spacing" onClick={() => dlg('paragraph')} />
      </Group>
    </>
  );
}

/* ======================= PICTURE (contextual) ======================= */
export function PictureTab({ c }) {
  const { editor } = c;
  const a = editor.getAttributes('image');
  const set = (v) => editor.chain().updateAttributes('image', v).run();
  const rotate = async (d) => set({ src: await rotateDataUrl(a.src, d), width: null, height: null });
  return (
    <>
      <Group title="Arrange">
        <Btn icon={PanelLeft} label="Float Left" on={a.align === 'left'} onClick={() => set({ align: 'left' })} />
        <Btn icon={AlignCenter} label="Centre" on={a.align === 'center'} onClick={() => set({ align: 'center' })} />
        <Btn icon={PanelRight} label="Float Right" on={a.align === 'right'} onClick={() => set({ align: 'right' })} />
        <Btn icon={Type} label="Inline" on={a.align === 'inline'} onClick={() => set({ align: 'inline' })} />
      </Group>
      <Group title="Size">
        {[25, 50, 75, 100].map((p) => <Btn key={p} label={`${p}%`} on={a.width === `${p}%`} onClick={() => set({ width: `${p}%`, height: null })} />)}
        <Btn icon={a.lock === false ? Unlock : Lock} label={a.lock === false ? 'Free' : 'Locked'} on={a.lock === false} title="Lock or unlock aspect ratio for free resizing" onClick={() => set({ lock: a.lock === false, height: null })} />
        <Btn icon={Undo2} label="Reset" onClick={() => set({ width: null, height: null })} />
        <Btn icon={Move} label="Position" title="Reset position (drag the picture to move it)" onClick={() => set({ dx: 0, dy: 0 })} />
      </Group>
      <Group title="Rotate">
        <Btn icon={RotateCcw} label="Left" onClick={() => rotate(-90)} />
        <Btn icon={RotateCw} label="Right" onClick={() => rotate(90)} />
      </Group>
      <Group title="Picture">
        <Btn icon={Download} label="Download" onClick={async () => { const b = await (await fetch(a.src)).blob(); saveBlob(`${a.alt || 'image'}.${(b.type.split('/')[1] || 'png').replace('svg+xml', 'svg')}`, b); }} />
        <Btn icon={Trash2} label="Delete" onClick={() => editor.chain().focus().deleteSelection().run()} />
      </Group>
      <div className="flex items-center px-3 text-xs opacity-60">Drag any handle to resize. Unlock the ratio for free resizing. The on-image toolbar has Crop, Replace and Properties.</div>
    </>
  );
}

/* ======================= TABLE (contextual) ======================= */
export function TableTab({ c }) {
  const { editor } = c;
  const ch = () => editor.chain().focus();
  const B = (label, cmd, args) => <Btn key={label} label={label} onClick={() => ch()[cmd](...(args || [])).run()} />;
  return (
    <>
      <Group title="Rows & Columns">
        {B('Row above', 'addRowBefore')}{B('Row below', 'addRowAfter')}{B('Delete row', 'deleteRow')}
        {B('Col before', 'addColumnBefore')}{B('Col after', 'addColumnAfter')}{B('Delete col', 'deleteColumn')}
      </Group>
      <Group title="Cells">
        {B('Merge', 'mergeCells')}{B('Split', 'splitCell')}{B('Header row', 'toggleHeaderRow')}
        <ColorMenu icon={Palette} label="Shade" onPick={(col) => ch().setCellAttribute('backgroundColor', col).run()} onClear={() => ch().setCellAttribute('backgroundColor', null).run()} clearLabel="No shading" />
      </Group>
      <Group title="Table">{B('Delete table', 'deleteTable')}</Group>
    </>
  );
}
void Plus; void MessageSquare; void Sep;

/* ======================= SHAPE FORMAT (contextual) ======================= */
export function ShapeTab({ c }) {
  const { editor, ask, flash } = c;
  const f = findShape(editor);
  if (!f) return null;
  const a = f.node.attrs;
  const set = (patch) => setShape(editor, patch);
  const MenuList = ({ label, icon, width = 200, items, current, onPick }) => (
    <Menu width={width} trigger={() => <Btn icon={icon} label={label} caret />}>
      {(close) => items.map(([v, n]) => <Item key={String(v)} on={current === v} onClick={() => { onPick(v); close(); }}>{n}</Item>)}
    </Menu>
  );
  return (
    <>
      <Group title="Shape">
        <MenuList icon={Shapes} label={SHAPE_KINDS[a.shape] || 'Shape'} width={250} items={Object.entries(SHAPE_KINDS)} current={a.shape} onPick={(v) => set({ shape: v })} />
        <Menu width={280} trigger={() => <Btn icon={Palette} label="Styles" caret />}>
          {(close) => SHAPE_PRESETS.map((p) => <Item key={p.id} onClick={() => { set({ ...SHAPE_DEFAULTS, ...p.attrs }); close(); }}>{p.label}</Item>)}
        </Menu>
      </Group>
      <Group title="Fill & Outline">
        <ColorMenu icon={Palette} label="Fill" onPick={(col) => set({ fill: col })} onClear={() => set({ fill: '' })} clearLabel="No fill" />
        <ColorMenu icon={Frame} label="Outline" onPick={(col) => set({ stroke: col, strokeW: a.strokeW || 2 })} onClear={() => set({ strokeW: 0 })} clearLabel="No outline" />
        <MenuList icon={Minus} label={`${a.strokeW}px`} width={160} items={[0, 1, 2, 3, 4, 6, 8].map((n) => [n, n ? `${n} px` : 'None'])} current={a.strokeW} onPick={(v) => set({ strokeW: v })} />
        <MenuList icon={Frame} label={a.strokeStyle} width={170} items={[['solid', 'Solid'], ['dashed', 'Dashed'], ['dotted', 'Dotted'], ['double', 'Double']]} current={a.strokeStyle} onPick={(v) => set({ strokeStyle: v })} />
      </Group>
      <Group title="Text">
        <ColorMenu icon={Type} label="Text" onPick={(col) => set({ color: col })} onClear={() => set({ color: '#111111' })} clearLabel="Automatic" />
        <Btn icon={Bold} title="Bold text" on={a.bold} onClick={() => set({ bold: !a.bold })} />
        {[['left', AlignLeft], ['center', AlignCenter], ['right', AlignRight]].map(([k, I]) => <Btn key={k} icon={I} title={`Align text ${k}`} on={a.textAlign === k} onClick={() => set({ textAlign: k })} />)}
      </Group>
      <Group title="Size & Position">
        <Menu width={210} trigger={() => <Btn icon={RectangleHorizontal} label={a.width} caret />}>
          {(close) => (<>
            {['25%', '33%', '50%', '66%', '75%', '100%'].map((w) => <Item key={w} on={a.width === w} onClick={() => { set({ width: w }); close(); }}>{w} of page width</Item>)}
            <Item onClick={() => { close(); ask('Shape width', 'Width, e.g. 320px or 60%', (v) => { if (/^\d+(\.\d+)?(px|%)$/.test(v)) set({ width: v }); else flash('Use a value like 320px or 60%'); }, a.width); }}>Custom…</Item>
          </>)}
        </Menu>
        <MenuList icon={Ruler} label="Padding" width={170} items={[[8, 'Small'], [14, 'Medium'], [24, 'Large'], [36, 'Extra large']]} current={a.pad} onPick={(v) => set({ pad: v })} />
        <MenuList icon={Frame} label="Corners" width={170} items={[[null, 'Default'], [0, 'Sharp'], [6, 'Small'], [14, 'Medium'], [24, 'Large'], [999, 'Round']]} current={a.radius} onPick={(v) => set({ radius: v })} />
        {[['left', PanelLeft], ['center', AlignCenter], ['right', PanelRight]].map(([k, I]) => <Btn key={k} icon={I} title={`Place ${k}`} on={a.align === k} onClick={() => set({ align: k })} />)}
        <Btn icon={ArrowUp} title="Move up" onClick={() => !moveShape(editor, -1) && flash('Already at the top')} />
        <Btn icon={ArrowDown} title="Move down" onClick={() => !moveShape(editor, 1) && flash('Already at the bottom')} />
      </Group>
      <Group title="Effects">
        <Btn icon={Droplets} label="Shadow" on={a.shadow} onClick={() => set({ shadow: !a.shadow })} />
        <Btn icon={Copy} label="Duplicate" onClick={() => duplicateShape(editor)} />
        <Btn icon={Trash2} label="Delete" onClick={() => deleteShape(editor)} />
      </Group>
    </>
  );
}
