import {
  List, Hash, ChevronLeft, ChevronRight, BookOpen, Quote, Captions, RefreshCw, Trash2, SpellCheck, Volume2, VolumeX,
  Languages, Lock, Unlock, BarChart3, Maximize2, FileText, Globe, BookOpenText, Ruler, Grid3x3, PanelLeft, ZoomIn, Sun, Moon, Monitor,
} from 'lucide-react';
import { Btn, Group, Item, Sep, Menu } from './ui.jsx';
import { insertToc, updateToc, removeToc, insertNote, gotoNote, inText, insertBibliography, nextCaption } from '../services/refs.js';

/* ======================= REFERENCES ======================= */
export function ReferencesTab({ c }) {
  const { editor, meta, setMeta, dlg, flash, ask } = c;
  const ch = () => editor.chain().focus();
  const cap = (label) => { const n = nextCaption(editor, label); ch().insertContent(`<p style="text-align:center"><em>${label} ${n}: </em></p>`).run(); };
  return (
    <>
      <Group title="Table of Contents">
        <Menu width={250} trigger={() => <Btn icon={List} label="Contents" caret />}>
          {(close) => (<>
            <Item onClick={() => { insertToc(editor, 3); close(); }}>Automatic Table</Item>
            <Item onClick={() => { dlg('toc'); close(); }}>Custom Table…</Item>
            <Item icon={RefreshCw} onClick={() => { if (!updateToc(editor)) flash('Insert a table of contents first'); close(); }}>Update Table</Item>
            <Item icon={Trash2} onClick={() => { if (!removeToc(editor)) flash('There is no table of contents'); close(); }}>Remove Table</Item>
          </>)}
        </Menu>
      </Group>
      <Group title="Footnotes">
        <Btn icon={Hash} label="Footnote" onClick={() => ask('Insert Footnote', 'Footnote text', (t) => insertNote(editor, t, 'footnote'))} />
        <Btn icon={Hash} label="Endnote" onClick={() => ask('Insert Endnote', 'Endnote text', (t) => insertNote(editor, t, 'endnote'))} />
        <Btn icon={ChevronLeft} title="Previous note" onClick={() => !gotoNote(editor, -1) && flash('No notes yet')} />
        <Btn icon={ChevronRight} title="Next note" onClick={() => !gotoNote(editor, 1) && flash('No notes yet')} />
      </Group>
      <Group title="Citations & Bibliography">
        <Menu width={290} trigger={() => <Btn icon={Quote} label="Citation" caret />}>
          {(close) => (<>
            {meta.sources.map((s, i) => <Item key={s.id} onClick={() => { ch().insertContent(inText(s, meta.citeStyle, i)).run(); close(); }}>{s.author.split(',')[0]} ({s.year})</Item>)}
            <Item onClick={() => { dlg('sources'); close(); }}>Add New Source…</Item>
          </>)}
        </Menu>
        <Btn icon={BookOpen} label="Sources" onClick={() => dlg('sources')} />
        <Menu width={240} trigger={() => <Btn icon={BookOpenText} label="Bibliography" caret />}>
          {(close) => ['Bibliography', 'Works Cited', 'References'].map((h) => (
            <Item key={h} onClick={() => { if (!meta.sources.length) flash('Add a source first'); else insertBibliography(editor, meta.sources, meta.citeStyle, h); close(); }}>Insert {h}</Item>
          ))}
        </Menu>
      </Group>
      <Group title="Captions">
        <Menu width={220} trigger={() => <Btn icon={Captions} label="Caption" caret />}>
          {(close) => ['Table', 'Figure', 'Equation'].map((l) => <Item key={l} onClick={() => { cap(l); close(); }}>{l} Caption</Item>)}
        </Menu>
      </Group>
    </>
  );
}

/* ======================= REVIEW ======================= */
export function ReviewTab({ c }) {
  const { editor, meta, setMeta, dlg, flash, view } = c;
  const speak = () => {
    if (!('speechSynthesis' in window)) { flash('Read Aloud is not available on this device'); return; }
    const { from, to, empty } = editor.state.selection;
    const text = empty ? editor.getText() : editor.state.doc.textBetween(from, to, ' ');
    if (!text.trim()) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); u.lang = meta.lang; window.speechSynthesis.speak(u);
  };
  const toggleSpell = () => {
    const on = editor.view.dom.getAttribute('spellcheck') !== 'false';
    editor.view.dom.setAttribute('spellcheck', on ? 'false' : 'true'); flash(on ? 'Spell check off' : 'Spell check on');
  };
  return (
    <>
      <Group title="Proofing">
        <Btn icon={SpellCheck} label="Spelling" onClick={toggleSpell} />
        <Btn icon={BarChart3} label="Word Count" onClick={() => dlg('stats')} />
        <Btn icon={Volume2} label="Read Aloud" onClick={speak} />
        <Btn icon={VolumeX} title="Stop" onClick={() => window.speechSynthesis?.cancel()} />
      </Group>
      <Group title="Language">
        <Menu width={230} trigger={() => <Btn icon={Languages} label={meta.lang} caret />}>
          {(close) => [['English (US)', 'en-US'], ['English (UK)', 'en-GB'], ['Hindi', 'hi-IN'], ['Marathi', 'mr-IN']].map(([n, l]) => <Item key={l} on={meta.lang === l} onClick={() => { setMeta({ lang: l }); close(); }}>{n}</Item>)}
        </Menu>
      </Group>
      <Group title="Protect">
        {view.locked
          ? <Btn icon={Unlock} label="Remove Protection" onClick={() => view.setLocked(false)} />
          : <Btn icon={Lock} label="Protect Document" onClick={() => { view.setLocked(true); flash('Document is read-only. Tap Remove Protection to edit.'); }} />}
      </Group>
      <div className="flex items-center px-3 text-xs opacity-60">Comments and Track Changes are coming in the next update.</div>
    </>
  );
}

/* ======================= VIEW ======================= */
export function ViewTab({ c }) {
  const { dlg, view } = c;
  const pg = view.pageNav;
  const Z = [50, 75, 100, 125, 150, 175, 200];
  return (
    <>
      <Group title="Views">
        {[['page', 'Page View', FileText], ['print', 'Print Layout', FileText], ['web', 'Web Layout', Globe], ['read', 'Read Mode', BookOpenText]].map(([k, n, I]) => <Btn key={k} icon={I} label={n} on={view.mode === k} onClick={() => view.setMode(k)} />)}
      </Group>
      <Group title="Focus">
        <Btn icon={Maximize2} label="Focus Mode" on={view.focus} onClick={() => view.setFocus(!view.focus)} />
      </Group>
      <Group title="Show">
        <Btn icon={Ruler} label="Ruler" on={view.ruler} onClick={() => view.setRuler(!view.ruler)} />
        <Btn icon={Grid3x3} label="Gridlines" on={view.grid} onClick={() => view.setGrid(!view.grid)} />
        <Btn icon={PanelLeft} label="Navigation" on={view.outline && view.navTab === 'pages'} onClick={() => { view.setNavTab('pages'); view.setOutline(view.navTab === 'pages' ? !view.outline : true); }} />
        <Btn icon={List} label="Outline" on={view.outline && view.navTab === 'headings'} onClick={() => { view.setNavTab('headings'); view.setOutline(view.navTab === 'headings' ? !view.outline : true); }} />
        <Btn icon={Ruler} label="Boundaries" on={view.boundaries} onClick={() => view.setBoundaries(!view.boundaries)} />
      </Group>
      <Group title="Pages">
        <Btn icon={ChevronLeft} title="Previous page" disabled={pg.page <= 1} onClick={() => pg.go(pg.page - 1)} />
        <Btn label={`${pg.page} / ${pg.pages}`} title="Pages panel" on={view.outline && view.navTab === 'pages'} onClick={() => { view.setNavTab('pages'); view.setOutline(view.navTab === 'pages' ? !view.outline : true); }} />
        <Btn icon={ChevronRight} title="Next page" disabled={pg.page >= pg.pages} onClick={() => pg.go(pg.page + 1)} />
      </Group>
      <Group title="Zoom">
        <Menu width={200} trigger={() => <Btn icon={ZoomIn} label={`${Math.round(view.zoom * 100)}%`} caret />}>
          {(close) => (<>
            {Z.map((z) => <Item key={z} on={Math.round(view.zoom * 100) === z} onClick={() => { view.setZoom(z / 100); close(); }}>{z}%</Item>)}
            <Sep>Fit</Sep>
            <Item onClick={() => { view.fit('width'); close(); }}>Fit Width</Item>
            <Item onClick={() => { view.fit('page'); close(); }}>One Page</Item>
            <Item onClick={() => { view.setZoom(0.5); close(); }}>Multiple Pages</Item>
          </>)}
        </Menu>
        <Btn title="Zoom out" onClick={() => view.setZoom(Math.max(0.25, +(view.zoom - 0.1).toFixed(2)))}><span className="text-lg font-bold">−</span></Btn>
        <Btn title="Zoom in" onClick={() => view.setZoom(Math.min(3, +(view.zoom + 0.1).toFixed(2)))}><span className="text-lg font-bold">+</span></Btn>
      </Group>
      <Group title="Theme">
        {[['light', 'Light', Sun], ['dark', 'Dark', Moon], ['system', 'System', Monitor]].map(([k, n, I]) => <Btn key={k} icon={I} label={n} on={view.theme === k} onClick={() => view.setTheme(k)} />)}
      </Group>
      <Group title="Document">
        <Btn icon={BarChart3} label="Statistics" onClick={() => dlg('stats')} />
      </Group>
    </>
  );
}
