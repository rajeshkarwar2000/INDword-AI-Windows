/** Finds text across a ProseMirror doc. Each match is { from, to } in document positions. */
export function findAll(editor, term, matchCase = false) {
  if (!term) return [];
  const out = [];
  const needle = matchCase ? term : term.toLowerCase();
  editor.state.doc.descendants((node, pos) => {
    if (!node.isTextblock) return true;
    const text = node.textBetween(0, node.content.size, '\0', '\0');
    const hay = matchCase ? text : text.toLowerCase();
    let i = hay.indexOf(needle);
    while (i !== -1) {
      out.push({ from: pos + 1 + i, to: pos + 1 + i + term.length });
      i = hay.indexOf(needle, i + term.length);
    }
    return false;
  });
  return out;
}

export function selectMatch(editor, m) {
  editor.chain().focus().setTextSelection({ from: m.from, to: m.to }).scrollIntoView().run();
}

export function replaceMatch(editor, m, text) {
  editor.chain().focus().insertContentAt({ from: m.from, to: m.to }, text).run();
}

export function replaceAll(editor, term, text, matchCase) {
  const all = findAll(editor, term, matchCase).reverse();
  if (!all.length) return 0;
  const chain = editor.chain();
  all.forEach((m) => chain.insertContentAt({ from: m.from, to: m.to }, text));
  chain.run();
  return all.length;
}
