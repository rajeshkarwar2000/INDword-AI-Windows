import { createStore, get, set, del, entries } from 'idb-keyval';
import { newMeta } from '../constants.js';

const db = createStore('indword', 'kv');
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

/* ----- documents ----- */
export async function createDoc({ name = 'Untitled Document', html = '<p></p>', folder = '', meta, ext = 'indword' }) {
  const now = Date.now();
  const doc = { id: uid(), name, ext, html, folder, pinned: false, created: now, modified: now, meta: { ...newMeta(), ...(meta || {}) } };
  await set(`doc:${doc.id}`, doc, db);
  return doc;
}
export const saveDoc = (doc) => set(`doc:${doc.id}`, { ...doc, modified: Date.now() }, db);
export const getDoc = (id) => get(`doc:${id}`, db);
export const deleteDoc = (id) => del(`doc:${id}`, db);
export async function listDocs() {
  const all = await entries(db);
  return all.filter(([k]) => String(k).startsWith('doc:')).map(([, v]) => v);
}

/* ----- image library ----- */
export async function addLibraryImage({ name, type, size, dataUrl }) {
  const img = { id: uid(), name, type, size, dataUrl, added: Date.now() };
  await set(`img:${img.id}`, img, db);
  return img;
}
export async function listLibraryImages() {
  const all = await entries(db);
  return all.filter(([k]) => String(k).startsWith('img:')).map(([, v]) => v).sort((a, b) => b.added - a.added);
}
export const deleteLibraryImage = (id) => del(`img:${id}`, db);

/* ----- folders & settings ----- */
export const getFolders = async () => (await get('folders', db)) || [];
export const setFolders = (f) => set('folders', f, db);
export const DEFAULT_SETTINGS = {
  theme: 'system', sidebarOpen: true,
  autosave: true, autosaveMs: 1500,
  glassStyle: 'frosted', glassBlur: 20, glassOpacity: 0.75, glassBorder: 0.25, glassShadow: 1, glassSat: 1.5, glassSheen: 0.35, glassTint: 0, glassRim: 0.35, glassRimColor: 'white', glassBright: 1, glassGrain: 0, glassControls: true,
  glassRibbon: true, glassSide: true, glassMenu: true, glassStatus: true, glassCard: true, pageOpacity: 1, reduceEffects: false, reduceMotion: false,
  accent: '#3b82f6', wallpaper: 'aurora', radius: 1, uiScale: 1, scrollSize: 14,
  defaultZoom: 1, pageSize: 'A4', marginPreset: 'normal', fontSet: 'office', showRuler: false, showBoundaries: false,
};
export const getSettings = async () => ({ ...DEFAULT_SETTINGS, ...((await get('settings', db)) || {}) });
export const setSettings = (s) => set('settings', s, db);

/* ----- custom templates ----- */
export async function saveTemplate({ name, desc = 'My custom template', html, meta }) {
  const t = { id: `tpl-${uid()}`, name, desc, html, meta, custom: true };
  await set(`tpl:${t.id}`, t, db);
  return t;
}
export async function listTemplates() {
  const all = await entries(db);
  return all.filter(([k]) => String(k).startsWith('tpl:')).map(([, v]) => v);
}
export const deleteTemplate = (id) => del(`tpl:${id}`, db);
