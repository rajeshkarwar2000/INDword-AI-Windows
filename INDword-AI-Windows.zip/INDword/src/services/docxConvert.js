/* DOCX → HTML converter that keeps the *look* of the document: table shading and borders, paragraph shading and
   borders, colours, fonts, sizes, columns, images, page size and margins. Pure functions: no browser APIs needed. */

const TWIP = 1 / 15;
const px = (tw) => Math.round(Number(tw) * TWIP * 100) / 100;
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escAttr = (s) => esc(s).replace(/"/g, '&quot;');

/* ---------------- tiny XML parser ---------------- */
const decode = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (_, e) => {
  if (e[0] === '#') return String.fromCodePoint(e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10));
  return { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }[e.toLowerCase()];
});
export function parseXml(src) {
  const text = src.replace(/<\?[\s\S]*?\?>/g, '').replace(/<!--[\s\S]*?-->/g, '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (_, t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;'));
  const root = { n: '#root', a: {}, c: [] };
  const stack = [root];
  const re = /<(\/?)([A-Za-z_][\w:.-]*)((?:\s+[\w:.-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|([^<]+)/g;
  let m;
  while ((m = re.exec(text))) {
    if (m[5] !== undefined) { const t = decode(m[5]); if (t) stack[stack.length - 1].c.push(t); }
    else if (m[1]) { if (stack.length > 1) stack.pop(); }
    else {
      const a = {};
      m[3].replace(/([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g, (_, k, v1, v2) => { a[k] = decode(v1 ?? v2 ?? ''); return ''; });
      const node = { n: m[2], a, c: [] };
      stack[stack.length - 1].c.push(node);
      if (!m[4]) stack.push(node);
    }
  }
  return root.c.find((x) => typeof x !== 'string');
}

const kids = (n, name) => (n?.c || []).filter((x) => typeof x !== 'string' && x.n === name);
const kid = (n, name) => kids(n, name)[0];
const elems = (n) => (n?.c || []).filter((x) => typeof x !== 'string');
const V = (n) => n?.a?.['w:val'];
const on = (n) => (n ? !['0', 'false', 'off'].includes(V(n)) : undefined);
const find = (n, name, out = []) => { elems(n).forEach((c) => { if (c.n === name) out.push(c); find(c, name, out); }); return out; };
const textOf = (n) => (n?.c || []).map((x) => (typeof x === 'string' ? x : textOf(x))).join('');

const HL = { yellow: '#ffff00', green: '#00ff00', cyan: '#00ffff', magenta: '#ff00ff', blue: '#0000ff', red: '#ff0000', darkBlue: '#00008b', darkCyan: '#008b8b', darkGreen: '#006400', darkMagenta: '#8b008b', darkRed: '#8b0000', darkYellow: '#808000', darkGray: '#a9a9a9', lightGray: '#d3d3d3', black: '#000000', white: '#ffffff' };
const BORDER_STYLE = { single: 'solid', thick: 'solid', double: 'double', dotted: 'dotted', dashed: 'dashed', dashSmallGap: 'dashed', dotDash: 'dashed', dotDotDash: 'dashed', wave: 'solid', triple: 'double', thinThickSmallGap: 'double', thickThinSmallGap: 'double' };
const hex = (c) => (c && c !== 'auto' && /^[0-9a-f]{6}$/i.test(c) ? `#${c}` : null);

/* ---------------- property readers ---------------- */
function readRPr(r) {
  const o = {};
  if (!r) return o;
  const flag = (k, name) => { const n = kid(r, name); if (n) o[k] = on(n); };
  flag('b', 'w:b'); flag('i', 'w:i'); flag('strike', 'w:strike'); flag('dstrike', 'w:dstrike'); flag('caps', 'w:caps');
  const u = kid(r, 'w:u'); if (u) o.u = V(u) === 'none' ? false : (V(u) || 'single');
  const col = kid(r, 'w:color'); if (col && hex(V(col))) o.color = hex(V(col));
  const sz = kid(r, 'w:sz'); if (sz) o.sz = Number(V(sz)) / 2;
  const rf = kid(r, 'w:rFonts'); if (rf) { const f = rf.a['w:ascii'] || rf.a['w:hAnsi']; if (f) o.font = f; }
  const hl = kid(r, 'w:highlight'); if (hl && HL[V(hl)]) o.hl = HL[V(hl)];
  const shd = kid(r, 'w:shd'); if (shd && hex(shd.a['w:fill'])) o.shd = hex(shd.a['w:fill']);
  const va = kid(r, 'w:vertAlign'); if (va) o.vert = V(va);
  const rs = kid(r, 'w:rStyle'); if (rs) o.rStyle = V(rs);
  return o;
}
function readBorder(n) {
  if (!n) return undefined;
  const v = V(n);
  if (!v || v === 'nil' || v === 'none') return { none: true };
  return { style: BORDER_STYLE[v] || 'solid', color: hex(n.a['w:color']) || '#000000', w: Math.max(1, Math.round(Number(n.a['w:sz'] || 4) / 6)), space: Number(n.a['w:space'] || 0) };
}
function readPPr(p) {
  const o = {};
  if (!p) return o;
  const jc = kid(p, 'w:jc'); if (jc) o.jc = { center: 'center', right: 'right', end: 'right', both: 'justify', distribute: 'justify' }[V(jc)] || 'left';
  const sp = kid(p, 'w:spacing'); if (sp) o.spacing = { before: sp.a['w:before'], after: sp.a['w:after'], line: sp.a['w:line'], rule: sp.a['w:lineRule'] };
  const ind = kid(p, 'w:ind'); if (ind) o.ind = { left: ind.a['w:left'] ?? ind.a['w:start'], right: ind.a['w:right'] ?? ind.a['w:end'], first: ind.a['w:firstLine'], hanging: ind.a['w:hanging'] };
  const shd = kid(p, 'w:shd'); if (shd && hex(shd.a['w:fill'])) o.shd = hex(shd.a['w:fill']);
  const bd = kid(p, 'w:pBdr');
  if (bd) { o.bdr = {}; ['top', 'left', 'bottom', 'right'].forEach((s) => { const b = readBorder(kid(bd, `w:${s}`)); if (b) o.bdr[s] = b; }); }
  const np = kid(p, 'w:numPr'); if (np) o.num = { id: V(kid(np, 'w:numId')), lvl: Number(V(kid(np, 'w:ilvl')) || 0) };
  const ps = kid(p, 'w:pStyle'); if (ps) o.style = V(ps);
  if (kid(p, 'w:pageBreakBefore')) o.pbb = true;
  const ol = kid(p, 'w:outlineLvl'); if (ol) o.outline = Number(V(ol));
  return o;
}
const mergeP = (a = {}, b = {}) => {
  const o = { ...a, ...b };
  ['spacing', 'ind'].forEach((k) => { if (a[k] || b[k]) { o[k] = { ...(a[k] || {}) }; Object.entries(b[k] || {}).forEach(([kk, v]) => { if (v !== undefined) o[k][kk] = v; }); } });
  if (a.bdr || b.bdr) o.bdr = { ...(a.bdr || {}), ...(b.bdr || {}) };
  return o;
};
const mergeR = (a = {}, b = {}) => ({ ...a, ...b });

/* ---------------- styles & numbering ---------------- */
function readStyles(root) {
  const out = { map: {}, defP: {}, defR: {}, defaultPara: null };
  if (!root) return out;
  const dd = kid(root, 'w:docDefaults');
  out.defR = readRPr(kid(kid(dd, 'w:rPrDefault'), 'w:rPr'));
  out.defP = readPPr(kid(kid(dd, 'w:pPrDefault'), 'w:pPr'));
  kids(root, 'w:style').forEach((s) => {
    const id = s.a['w:styleId'];
    out.map[id] = { type: s.a['w:type'], basedOn: V(kid(s, 'w:basedOn')), name: (V(kid(s, 'w:name')) || '').toLowerCase(), p: readPPr(kid(s, 'w:pPr')), r: readRPr(kid(s, 'w:rPr')) };
    if (s.a['w:type'] === 'paragraph' && s.a['w:default'] === '1') out.defaultPara = id;
  });
  return out;
}
function styleChain(st, id) {
  const chain = []; const seen = new Set();
  let cur = id;
  while (cur && st.map[cur] && !seen.has(cur)) { seen.add(cur); chain.unshift(st.map[cur]); cur = st.map[cur].basedOn; }
  return chain;
}
function readNumbering(root) {
  const abs = {}; const nums = {};
  if (!root) return { abs, nums };
  kids(root, 'w:abstractNum').forEach((a) => {
    const lv = {};
    kids(a, 'w:lvl').forEach((l) => { lv[l.a['w:ilvl']] = { fmt: V(kid(l, 'w:numFmt')) || 'decimal' }; });
    abs[a.a['w:abstractNumId']] = lv;
  });
  kids(root, 'w:num').forEach((n) => { nums[n.a['w:numId']] = V(kid(n, 'w:abstractNumId')); });
  return { abs, nums };
}

/* ---------------- main entry ---------------- */
export function convertDocx(io) {
  const notes = [];
  const note = (m) => { if (!notes.includes(m)) notes.push(m); };
  const docRoot = parseXml(io.text('word/document.xml') || '');
  if (!docRoot) throw new Error('This file has no readable document.xml');
  const body = kid(docRoot, 'w:body');
  const st = readStyles(parseXml(io.text('word/styles.xml') || '<x/>'));
  const numbering = readNumbering(parseXml(io.text('word/numbering.xml') || '<x/>'));
  const relsOf = (part) => {
    const dir = part.includes('/') ? part.slice(0, part.lastIndexOf('/') + 1) : '';
    const file = `${dir}_rels/${part.slice(part.lastIndexOf('/') + 1)}.rels`;
    const map = {};
    const r = parseXml(io.text(file) || '<x/>');
    kids(r, 'Relationship').forEach((x) => { map[x.a.Id] = { target: x.a.Target, mode: x.a.TargetMode, type: x.a.Type }; });
    return { map, dir };
  };
  const mainRels = relsOf('word/document.xml');
  const defaultParaId = st.defaultPara || 'Normal';

  const mediaUrl = (rels, id) => {
    const r = rels.map[id]; if (!r) return null;
    const path = r.target.startsWith('/') ? r.target.slice(1) : `${rels.dir}${r.target}`.replace(/[^/]+\/\.\.\//g, '');
    const b64 = io.base64(path);
    if (!b64) return null;
    const ext = path.split('.').pop().toLowerCase();
    const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml', webp: 'image/webp' }[ext];
    if (!mime) { note(`A .${ext} picture could not be shown (format not supported).`); return null; }
    return `data:${mime};base64,${b64}`;
  };

  /* ----- effective formatting ----- */
  const paraProps = (direct) => {
    let p = mergeP({}, st.defP);
    styleChain(st, direct.style || defaultParaId).forEach((s) => { p = mergeP(p, s.p); });
    return mergeP(p, direct);
  };
  const runBase = (styleId) => {
    let r = mergeR({}, st.defR);
    styleChain(st, styleId || defaultParaId).forEach((s) => { r = mergeR(r, s.r); });
    return r;
  };

  /* ----- drawings ----- */
  function drawingHtml(dr, rels, ctx) {
    const holder = elems(dr)[0]; if (!holder) return '';
    const ext = kid(holder, 'wp:extent');
    const w = ext ? Math.round(Number(ext.a.cx) / 9525) : 0;
    const blip = find(dr, 'a:blip')[0];
    const id = blip?.a['r:embed'];
    const src = id ? mediaUrl(rels, id) : null;
    if (!src) { if (find(dr, 'wps:txbx').length) note('Text boxes are not imported.'); return ''; }
    const doc = kid(holder, 'wp:docPr');
    const alt = doc?.a.descr || doc?.a.name || '';
    if (holder.n === 'wp:anchor' && ctx.header && holder.a.behindDoc === '1') { ctx.watermark = { src, w }; return ''; }
    let align = 'inline';
    if (holder.n === 'wp:anchor') {
      const a = textOf(find(holder, 'wp:align')[0]);
      if (a === 'left' || a === 'right' || a === 'center') align = a;
    }
    return `<img src="${src}" alt="${escAttr(alt)}" style="width:${w || 200}px;height:auto"${align !== 'inline' ? ` data-align="${align}"` : ''}>`;
  }
  function pictHtml(pict, rels) {
    const im = find(pict, 'v:imagedata')[0];
    const src = im ? mediaUrl(rels, im.a['r:id']) : null;
    if (!src) return '';
    const shape = find(pict, 'v:shape')[0];
    const wm = /width:\s*([\d.]+)pt/.exec(shape?.a.style || '');
    return `<img src="${src}" alt="" style="width:${wm ? Math.round(Number(wm[1]) * 1.333) : 200}px;height:auto">`;
  }

  /* ----- runs ----- */
  function runHtml(r, base, rels, ctx) {
    const props = mergeR(mergeR(base, readRPr(kid(r, 'w:rPr')).rStyle ? styleChain(st, readRPr(kid(r, 'w:rPr')).rStyle).reduce((a, s) => mergeR(a, s.r), {}) : {}), readRPr(kid(r, 'w:rPr')));
    let out = '';
    const addText = (t) => { out += esc(props.caps ? t.toUpperCase() : t); };
    const walk = (nodes) => {
      nodes.forEach((c) => {
        if (typeof c === 'string') return;
        switch (c.n) {
          case 'w:t': addText(textOf(c)); break;
          case 'w:tab': out += '\u00a0\u00a0\u00a0\u00a0'; break;
          case 'w:noBreakHyphen': out += '-'; break;
          case 'w:br': out += c.a['w:type'] === 'page' ? '\u0000PB\u0000' : '<br>'; break;
          case 'w:cr': out += '<br>'; break;
          case 'w:drawing': out += `\u0001${drawingHtml(c, rels, ctx)}\u0001`; break;
          case 'w:pict': out += `\u0001${pictHtml(c, rels)}\u0001`; break;
          case 'w:footnoteReference': case 'w:endnoteReference': out += '<sup>*</sup>'; break;
          case 'mc:AlternateContent': { const fb = kid(c, 'mc:Fallback') || kid(c, 'mc:Choice'); if (fb) walk(elems(fb)); break; }
          default: break;
        }
      });
    };
    walk(elems(r));
    if (!out.replace(/\u0001[^\u0001]*\u0001/g, '').trim() && !/\u0001|\u0000PB|<br>/.test(out)) return out ? out : '';
    // images and page-break markers stay outside the text formatting
    return out.split(/(\u0001[^\u0001]*\u0001|\u0000PB\u0000)/).map((seg) => {
      if (!seg) return '';
      if (seg.startsWith('\u0001')) return seg.slice(1, -1);
      if (seg === '\u0000PB\u0000') return seg;
      let h = seg;
      const css = [];
      const font = props.font; const size = props.sz;
      if (font) css.push(`font-family:${/[ ,]/.test(font) ? `'${font}'` : font},${/(cambria|times|georgia|garamond|palatino|book antiqua|serif)/i.test(font) && !/sans/i.test(font) ? 'serif' : /(courier|consolas|mono)/i.test(font) ? 'monospace' : 'sans-serif'}`);
      if (size && size !== 12) css.push(`font-size:${size}pt`);
      if (props.color) css.push(`color:${props.color}`);
      if (props.u && props.u !== 'single' && props.u !== 'words') css.push(`text-decoration:underline ${{ double: 'double', dotted: 'dotted', dash: 'dashed', wave: 'wavy' }[props.u] || 'solid'}`);
      if (props.dstrike) css.push('text-decoration:line-through double');
      if (css.length) h = `<span style="${css.join(';')}">${h}</span>`;
      if (props.u && (props.u === 'single' || props.u === 'words')) h = `<u>${h}</u>`;
      if (props.strike && !props.dstrike) h = `<s>${h}</s>`;
      if (props.vert === 'superscript') h = `<sup>${h}</sup>`;
      if (props.vert === 'subscript') h = `<sub>${h}</sub>`;
      if (props.i) h = `<em>${h}</em>`;
      if (props.b) h = `<strong>${h}</strong>`;
      const bg = props.hl || props.shd;
      if (bg) h = `<mark data-color="${bg}" style="background-color:${bg}">${h}</mark>`;
      return h;
    }).join('');
  }
  function inlineHtml(nodes, base, rels, ctx) {
    let out = '';
    nodes.forEach((c) => {
      if (typeof c === 'string') return;
      switch (c.n) {
        case 'w:r': out += runHtml(c, base, rels, ctx); break;
        case 'w:hyperlink': {
          const inner = inlineHtml(elems(c), base, rels, ctx);
          const target = c.a['r:id'] ? rels.map[c.a['r:id']]?.target : (c.a['w:anchor'] ? null : null);
          out += target && /^(https?:|mailto:|tel:)/i.test(target) ? `<a href="${escAttr(target)}">${inner}</a>` : inner;
          break;
        }
        case 'w:ins': case 'w:smartTag': case 'w:fldSimple': case 'w:customXml': case 'w:sdtContent': case 'w:sdt': case 'w:bdo': case 'w:dir':
          out += inlineHtml(c.n === 'w:sdt' ? elems(kid(c, 'w:sdtContent')) : elems(c), base, rels, ctx); break;
        case 'mc:AlternateContent': { const fb = kid(c, 'mc:Fallback') || kid(c, 'mc:Choice'); if (fb) out += inlineHtml(elems(fb), base, rels, ctx); break; }
        default: break;
      }
    });
    return out;
  }

  /* ----- paragraphs ----- */
  const sideCss = (b, side) => (b.none ? `border-${side}:none` : `border-${side}:${b.w}px ${b.style} ${b.color}`);
  function paragraph(p, rels, ctx, inCell) {
    const direct = readPPr(kid(p, 'w:pPr'));
    const eff = paraProps(direct);
    const styleName = st.map[direct.style || defaultParaId]?.name || '';
    const chainNames = styleChain(st, direct.style || defaultParaId).map((s) => s.name);
    const base = runBase(direct.style);
    const inner = inlineHtml(elems(p), base, rels, ctx);
    const num = eff.num && eff.num.id !== '0' ? eff.num : null;

    let level = 0;
    const hm = /^heading (\d)/.exec(styleName) || chainNames.map((n) => /^heading (\d)/.exec(n)).find(Boolean);
    if (hm) level = Math.min(Number(hm[1]), 4); else if (eff.outline !== undefined && eff.outline < 4 && !num) level = eff.outline + 1;
    const cls = styleName === 'title' ? 'title' : styleName === 'subtitle' ? 'subtitle' : styleName === 'quote' ? 'quote' : styleName === 'intense quote' ? 'intense' : styleName === 'no spacing' ? 'nospacing' : '';

    const css = [];
    if (eff.jc && eff.jc !== 'left') css.push(`text-align:${eff.jc}`);
    if (!num) {
      const sp = eff.spacing || {};
      css.push(`margin-top:${sp.before ? px(sp.before) : 0}px`, `margin-bottom:${sp.after ? px(sp.after) : 0}px`);
      if (sp.line) css.push(`line-height:${sp.rule === 'exact' || sp.rule === 'atLeast' ? `${px(sp.line)}px` : (Number(sp.line) / 240).toFixed(2)}`); else css.push('line-height:1.2');
      const ind = eff.ind || {};
      if (ind.left) css.push(`margin-left:${px(ind.left)}px`);
      if (ind.right) css.push(`margin-right:${px(ind.right)}px`);
      if (ind.first) css.push(`text-indent:${px(ind.first)}px`);
      if (ind.hanging) css.push(`text-indent:-${px(ind.hanging)}px`);
      if (eff.shd) css.push(`background-color:${eff.shd}`);
    }
    let bdr = '';
    if (eff.bdr && !num) {
      const parts = []; let pad = 0;
      Object.entries(eff.bdr).forEach(([s, b]) => { parts.push(sideCss(b, s)); if (!b.none) pad = Math.max(pad, Math.round(b.space * 1.33)); });
      if (parts.length) bdr = ` data-borders="${escAttr(`${parts.join(';')};padding:${Math.max(pad, eff.shd ? 4 : 0)}px ${Math.max(pad, eff.shd ? 6 : 0)}px`)}"`;
    }
    const tag = level ? `h${level}` : 'p';
    const attrs = ` style="${css.join(';')}"${cls ? ` class="ps-${cls}"` : ''}${bdr}`;

    // page breaks inside a paragraph become real page-break blocks
    const segs = inner.split('\u0000PB\u0000');
    let html = '';
    segs.forEach((seg, i) => {
      if (i > 0) html += '<div data-page-break></div>';
      const keep = seg.trim() !== '' || segs.length === 1;
      if (keep) html += `<${tag}${num ? '' : attrs}>${seg}</${tag}>`;
    });
    if (direct.pbb) html = `<div data-page-break></div>${html}`;
    void inCell;
    return { html, num, tag, sect: kid(kid(p, 'w:pPr'), 'w:sectPr'), inner: html };
  }

  /* ----- lists ----- */
  const listFmt = (num) => {
    const abs = numbering.nums[num.id]; const lv = numbering.abs[abs]?.[String(num.lvl)];
    return lv && lv.fmt !== 'bullet' && lv.fmt !== 'none' ? 'ol' : 'ul';
  };
  function listHtml(items) {
    let out = ''; const open = [];
    items.forEach((it) => {
      const L = Math.min(it.lvl, 8);
      if (open.length === 0) { for (let d = 0; d <= L; d += 1) { open.push(it.fmt); out += `<${it.fmt}><li>`; } }
      else if (L > open.length - 1) { for (let d = open.length; d <= L; d += 1) { open.push(it.fmt); out += `<${it.fmt}><li>`; } }
      else {
        while (open.length - 1 > L) out += `</li></${open.pop()}>`;
        if (open[L] !== it.fmt) { out += `</li></${open[L]}><${it.fmt}><li>`; open[L] = it.fmt; } else out += '</li><li>';
      }
      out += it.html;
    });
    while (open.length) out += `</li></${open.pop()}>`;
    return out;
  }

  /* ----- tables ----- */
  function table(tbl, rels, ctx) {
    const pr = kid(tbl, 'w:tblPr');
    const grid = kids(kid(tbl, 'w:tblGrid'), 'w:gridCol').map((g) => Number(g.a['w:w']));
    const tb = {};
    const tbn = kid(pr, 'w:tblBorders');
    if (tbn) ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].forEach((s) => { const b = readBorder(kid(tbn, `w:${s}`)); if (b) tb[s] = b; });
    const mar = { top: 0, right: 7, bottom: 0, left: 7 };
    const cm = kid(pr, 'w:tblCellMar');
    if (cm) ['top', 'right', 'bottom', 'left'].forEach((s) => { const n = kid(cm, `w:${s}`) || kid(cm, `w:${s === 'left' ? 'start' : s === 'right' ? 'end' : s}`); if (n) mar[s] = Math.round(px(n.a['w:w'])); });
    const rows = kids(tbl, 'w:tr');
    const open = {}; const recs = [];
    rows.forEach((tr, ri) => {
      let col = 0; const cells = [];
      kids(tr, 'w:tc').forEach((tc) => {
        const tp = kid(tc, 'w:tcPr');
        const span = Number(V(kid(tp, 'w:gridSpan')) || 1);
        const vm = kid(tp, 'w:vMerge');
        const vmv = vm ? (V(vm) || 'continue') : null;
        if (vmv === 'continue' && open[col]) { open[col].rowspan += 1; col += span; return; }
        const rec = { tc, tp, span, col, ri, rowspan: 1 };
        if (vmv === 'restart') open[col] = rec; else delete open[col];
        cells.push(rec); col += span;
      });
      recs.push(cells);
    });
    const totalCols = grid.length || Math.max(1, ...recs.map((c) => c.reduce((a, x) => a + x.span, 0)));
    const css = (b, s) => (b ? sideCss(b, s) : `border-${s}:none`);
    let html = '<table><tbody>';
    recs.forEach((cells) => {
      html += '<tr>';
      cells.forEach((c) => {
        const last = c.ri + c.rowspan - 1 === rows.length - 1;
        const edge = {
          top: c.ri === 0 ? tb.top : tb.insideH, bottom: last ? tb.bottom : tb.insideH,
          left: c.col === 0 ? tb.left : tb.insideV, right: c.col + c.span >= totalCols ? tb.right : tb.insideV,
        };
        const tcb = kid(c.tp, 'w:tcBorders');
        if (tcb) {
          const get = (s, alt) => readBorder(kid(tcb, `w:${s}`) || (alt ? kid(tcb, `w:${alt}`) : null));
          const t = get('top'); if (t) edge.top = t;
          const b = get('bottom'); if (b) edge.bottom = b;
          const l = get('left', 'start'); if (l) edge.left = l;
          const r = get('right', 'end'); if (r) edge.right = r;
        }
        const cmar = { ...mar };
        const tcm = kid(c.tp, 'w:tcMar');
        if (tcm) ['top', 'right', 'bottom', 'left'].forEach((s) => { const n = kid(tcm, `w:${s}`) || kid(tcm, `w:${s === 'left' ? 'start' : s === 'right' ? 'end' : s}`); if (n) cmar[s] = Math.round(px(n.a['w:w'])); });
        const shd = hex(kid(c.tp, 'w:shd')?.a['w:fill']);
        const va = V(kid(c.tp, 'w:vAlign'));
        const cs = [css(edge.top, 'top'), css(edge.left, 'left'), css(edge.bottom, 'bottom'), css(edge.right, 'right'), `padding:${cmar.top}px ${cmar.right}px ${cmar.bottom}px ${cmar.left}px`];
        if (va === 'center') cs.push('vertical-align:middle'); else if (va === 'bottom') cs.push('vertical-align:bottom');
        const widths = grid.slice(c.col, c.col + c.span).map((w) => Math.round(w * TWIP));
        const content = renderBlocks(elems(c.tc), rels, ctx, true);
        html += `<td${c.span > 1 ? ` colspan="${c.span}"` : ''}${c.rowspan > 1 ? ` rowspan="${c.rowspan}"` : ''}${widths.length === c.span && widths.every(Boolean) ? ` data-colwidth="${widths.join(',')}"` : ''} data-cs="${escAttr(cs.join(';'))}"${shd ? ` style="background-color:${shd}"` : ''}>${content || '<p></p>'}</td>`;
      });
      html += '</tr>';
    });
    return `${html}</tbody></table>`;
  }

  /* ----- block walker ----- */
  function renderBlocks(nodes, rels, ctx, inCell, sections) {
    let out = ''; let list = [];
    const flush = () => { if (list.length) { out += listHtml(list); list = []; } };
    const handle = (n) => {
      if (n.n === 'w:p') {
        const r = paragraph(n, rels, ctx, inCell);
        if (r.num) list.push({ lvl: r.num.lvl, fmt: listFmt(r.num), html: r.html.replace(/^<[a-z0-9]+[^>]*>/, '<p>').replace(/<\/h\d>$/, '</p>') });
        else { flush(); out += r.html; }
        if (r.sect && sections) { flush(); sections.push({ html: out, sect: r.sect }); out = ''; }
      } else if (n.n === 'w:tbl') { flush(); out += table(n, rels, ctx); }
      else if (n.n === 'w:sdt') elems(kid(n, 'w:sdtContent')).forEach(handle);
      else if (n.n === 'w:sdtContent' || n.n === 'w:customXml' || n.n === 'w:ins') elems(n).forEach(handle);
    };
    nodes.forEach(handle);
    flush();
    return out;
  }

  /* ----- header / footer / page setup ----- */
  const ctxBody = { header: false };
  const sections = [];
  let tail = renderBlocks(elems(body), mainRels, ctxBody, false, sections);
  const finalSect = kid(body, 'w:sectPr');
  sections.push({ html: tail, sect: finalSect });
  tail = '';
  const colsOf = (s) => { const c = kid(s, 'w:cols'); return { n: Number(c?.a['w:num'] || 1), sep: c?.a['w:sep'] === 'true' || c?.a['w:sep'] === '1', gap: c?.a['w:space'] ? Math.round(px(c.a['w:space'])) : 32 }; };
  const html = sections.map(({ html: h, sect }) => {
    const c = colsOf(sect);
    return c.n > 1 && h.trim() ? `<div data-columns="${c.n}" data-gap="${c.gap}"${c.sep ? ' data-sep="1"' : ''}>${h}</div>` : h;
  }).join('');

  const meta = {};
  const sectForPage = finalSect || sections[0]?.sect;
  const pg = kid(sectForPage, 'w:pgSz');
  if (pg) {
    const w = px(pg.a['w:w']); const h = px(pg.a['w:h']);
    const lo = Math.min(w, h); const hi = Math.max(w, h);
    const presets = { A4: [794, 1123], Letter: [816, 1056], Legal: [816, 1344], Executive: [696, 1008] };
    const hit = Object.entries(presets).find(([, [pw, ph]]) => Math.abs(lo - pw) < 14 && Math.abs(hi - ph) < 14);
    meta.size = hit ? hit[0] : 'A4';
    if (!hit) note('The page size was changed to A4.');
    meta.orientation = w > h ? 'landscape' : 'portrait';
  }
  const pm = kid(sectForPage, 'w:pgMar');
  if (pm) meta.margins = { top: Math.round(px(pm.a['w:top'])), right: Math.round(px(pm.a['w:right'])), bottom: Math.round(px(pm.a['w:bottom'])), left: Math.round(px(pm.a['w:left'])) };
  const pb = kid(sectForPage, 'w:pgBorders');
  if (pb) {
    const b = readBorder(kid(pb, 'w:top') || kid(pb, 'w:left'));
    if (b && !b.none) { meta.border = { style: b.style, color: b.color, width: b.w, shadow: false }; note('The page border is drawn at the edge of the page.'); }
  }
  // header and footer
  const refs = (s, tag) => kids(s, tag).map((r) => r.a['r:id']);
  const pickPart = (tag) => {
    for (const { sect } of [...sections].reverse()) {
      const ids = refs(sect, tag); if (ids.length) return ids[0];
    }
    return null;
  };
  const readPart = (rid, isHeader) => {
    const rel = rid && mainRels.map[rid]; if (!rel) return null;
    const part = `word/${rel.target}`;
    const root = parseXml(io.text(part) || '<x/>');
    const partRels = relsOf(part);
    const c = { header: isHeader, watermark: null };
    const paras = find(root, 'w:p').map((p) => textOf({ c: find(p, 'w:t') }).trim()).filter(Boolean);
    find(root, 'w:drawing').forEach((d) => drawingHtml(d, partRels, c));
    const field = /PAGE/.test(find(root, 'w:instrText').map(textOf).join(' ')) || find(root, 'w:fldSimple').some((f) => /PAGE/.test(f.a['w:instr'] || ''));
    return { text: paras.join(' · '), watermark: c.watermark, field };
  };
  const h = readPart(pickPart('w:headerReference'), true);
  const f = readPart(pickPart('w:footerReference'), false);
  if (h?.text) meta.header = h.text;
  if (f?.text) meta.footer = f.text;
  if (f?.field) meta.pageNumbers = true;
  if (h?.watermark) meta.watermark = { text: '', opacity: 1, image: h.watermark.src, imageWidth: h.watermark.w };

  return { html, meta, notes };
}
