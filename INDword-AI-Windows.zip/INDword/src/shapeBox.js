/* Editable text shapes: banners, rectangles, pills, arrows, bubbles... They hold real, editable paragraphs. */

export const SHAPE_DEFAULTS = {
  shape: 'rect', fill: '#dbeafe', stroke: '#2563eb', strokeW: 2, strokeStyle: 'solid', color: '#0f172a',
  width: '100%', align: 'center', textAlign: 'center', pad: 14, shadow: false, radius: null, bold: false,
};

export const SHAPE_KINDS = {
  rect: 'Rectangle', rounded: 'Rounded rectangle', pill: 'Pill / capsule', ellipse: 'Ellipse', accent: 'Banner with side bar',
  arrow: 'Arrow banner', chevron: 'Chevron', hexagon: 'Hexagon', parallelogram: 'Parallelogram', diamond: 'Diamond', bubble: 'Speech bubble',
};

const CLIP = {
  arrow: 'polygon(0 0, calc(100% - 30px) 0, 100% 50%, calc(100% - 30px) 100%, 0 100%)',
  chevron: 'polygon(0 0, calc(100% - 26px) 0, 100% 50%, calc(100% - 26px) 100%, 0 100%, 26px 50%)',
  hexagon: 'polygon(28px 0, calc(100% - 28px) 0, 100% 50%, calc(100% - 28px) 100%, 28px 100%, 0 50%)',
  parallelogram: 'polygon(28px 0, 100% 0, calc(100% - 28px) 100%, 0 100%)',
  diamond: 'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)',
};
const RADIUS = { rect: '0', rounded: '14px', pill: '999px', ellipse: '50%', accent: '4px', bubble: '18px' };

/** Builds the inline CSS for a shape from its attributes. */
export function shapeCss(raw) {
  const a = { ...SHAPE_DEFAULTS, ...raw };
  const clip = CLIP[a.shape];
  const padX = a.pad + (clip ? 22 : 0) + (a.shape === 'ellipse' ? 22 : 0) + (a.shape === 'diamond' ? 26 : 0);
  const padY = a.pad + (a.shape === 'ellipse' ? 8 : 0) + (a.shape === 'diamond' ? 22 : 0);
  const css = [
    `--fill:${a.fill || 'transparent'}`, `--stroke:${a.stroke || 'transparent'}`,
    `background:${a.fill || 'transparent'}`, `color:${a.color}`, `width:${a.width || '100%'}`, 'box-sizing:border-box', 'position:relative',
    `padding:${padY}px ${padX}px`, `text-align:${a.textAlign}`, 'min-height:36px',
    `border-radius:${a.radius !== null && a.radius !== undefined && !clip ? `${a.radius}px` : (RADIUS[a.shape] ?? '0')}`,
    a.align === 'left' ? 'margin-left:0;margin-right:auto' : a.align === 'right' ? 'margin-left:auto;margin-right:0' : 'margin-left:auto;margin-right:auto',
  ];
  if (clip) css.push(`clip-path:${clip}`);
  else if (a.shape === 'accent') css.push('border:0', `border-left:${Math.max(4, a.strokeW + 3)}px ${a.strokeStyle} ${a.stroke}`);
  else if (a.strokeW > 0) css.push(`border:${a.strokeW}px ${a.strokeStyle} ${a.stroke}`);
  else css.push('border:0');
  if (a.shadow && !clip) css.push('box-shadow:0 6px 16px rgba(0,0,0,.25)');
  if (a.bold) css.push('font-weight:700');
  return css.join(';');
}

/** React style object for previews and menus. */
export function cssToObj(str) {
  const o = {};
  str.split(';').filter(Boolean).forEach((pair) => {
    const i = pair.indexOf(':'); const k = pair.slice(0, i).trim(); const v = pair.slice(i + 1).trim();
    o[k.startsWith('--') ? k : k.replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = v;
  });
  return o;
}
export const previewStyle = (attrs) => ({
  ...cssToObj(shapeCss({ ...attrs, width: '100%', pad: 5 })), marginLeft: 0, marginRight: 0, minHeight: 34, fontSize: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: undefined,
});

const P = (id, label, attrs, text) => ({ id, label, text, attrs });
export const SHAPE_PRESETS = [
  P('heading', 'Heading banner', { shape: 'accent', fill: '#D3EEFA', stroke: '#0B6BBF', color: '#0B1F3F', textAlign: 'left', bold: true }, 'Heading text'),
  P('dark', 'Dark title bar', { shape: 'rect', fill: '#0B6BBF', stroke: '#0B6BBF', color: '#FFFFFF', textAlign: 'left', bold: true }, 'Title text'),
  P('navy', 'Navy panel', { shape: 'rect', fill: '#0B1F3F', stroke: '#C9A227', strokeW: 3, color: '#FFD54A', bold: true }, 'Panel text'),
  P('red', 'Red banner', { shape: 'rect', fill: '#B01E23', stroke: '#B01E23', color: '#FFFFFF', bold: true }, 'Banner text'),
  P('green', 'Green banner', { shape: 'rect', fill: '#1E7B3A', stroke: '#1E7B3A', color: '#FFFFFF', bold: true }, 'Banner text'),
  P('yellow', 'Yellow note', { shape: 'rounded', fill: '#FFE24D', stroke: '#E0B800', color: '#111111', textAlign: 'left' }, 'Note text'),
  P('rounded', 'Rounded box', { shape: 'rounded', fill: '#EEF2FF', stroke: '#6366F1', color: '#1E1B4B' }, 'Type here'),
  P('card', 'Card', { shape: 'rounded', fill: '#FFFFFF', stroke: '#CBD5E1', strokeW: 1, color: '#111111', textAlign: 'left', shadow: true }, 'Card text'),
  P('outline', 'Outline box', { shape: 'rect', fill: '', stroke: '#334155', color: '#111111', textAlign: 'left' }, 'Text box'),
  P('dashed', 'Dashed box', { shape: 'rect', fill: '#F1F5F9', stroke: '#94A3B8', strokeStyle: 'dashed', color: '#64748B' }, 'Placeholder'),
  P('frame', 'Double frame', { shape: 'rect', fill: '', stroke: '#1E293B', strokeW: 4, strokeStyle: 'double', color: '#111111' }, 'Framed text'),
  P('pill', 'Pill label', { shape: 'pill', fill: '#7C3AED', stroke: '#7C3AED', color: '#FFFFFF', width: '60%', pad: 8, bold: true }, 'Label'),
  P('ellipse', 'Ellipse', { shape: 'ellipse', fill: '#FDE68A', stroke: '#F59E0B', color: '#78350F', width: '60%' }, 'Ellipse'),
  P('arrow', 'Arrow banner', { shape: 'arrow', fill: '#2563EB', color: '#FFFFFF', textAlign: 'left', bold: true }, 'Arrow text'),
  P('chevron', 'Chevron', { shape: 'chevron', fill: '#059669', color: '#FFFFFF', bold: true }, 'Step'),
  P('hexagon', 'Hexagon', { shape: 'hexagon', fill: '#F97316', color: '#FFFFFF', width: '60%', bold: true }, 'Hexagon'),
  P('para', 'Parallelogram', { shape: 'parallelogram', fill: '#EC4899', color: '#FFFFFF', bold: true }, 'Text'),
  P('diamond', 'Diamond', { shape: 'diamond', fill: '#FACC15', color: '#111111', width: '50%', bold: true }, 'Diamond'),
  P('bubble', 'Speech bubble', { shape: 'bubble', fill: '#FFFFFF', stroke: '#3B82F6', color: '#111111', width: '70%', align: 'left', textAlign: 'left' }, 'Say something'),
];

/* ----- editor helpers ----- */
export function findShape(editor) {
  const sel = editor.state.selection;
  if (sel.node?.type?.name === 'shapeBox') return { node: sel.node, pos: sel.from };
  const { $from } = sel;
  for (let d = $from.depth; d > 0; d -= 1) {
    const n = $from.node(d);
    if (n.type.name === 'shapeBox') return { node: n, pos: $from.before(d) };
  }
  return null;
}
export function setShape(editor, patch) {
  const f = findShape(editor); if (!f) return;
  editor.view.dispatch(editor.state.tr.setNodeMarkup(f.pos, undefined, { ...f.node.attrs, ...patch }));
}
export function moveShape(editor, dir) {
  const f = findShape(editor); if (!f) return false;
  const { state } = editor; const $pos = state.doc.resolve(f.pos);
  const parent = $pos.parent; const idx = $pos.index(); const sib = idx + dir;
  if (sib < 0 || sib >= parent.childCount) return false;
  const size = f.node.nodeSize; let tr = state.tr;
  if (dir < 0) { const start = f.pos - parent.child(idx - 1).nodeSize; tr = tr.delete(f.pos, f.pos + size).insert(start, f.node); }
  else { const end = f.pos + size + parent.child(idx + 1).nodeSize; tr = tr.insert(end, f.node).delete(f.pos, f.pos + size); }
  editor.view.dispatch(tr.scrollIntoView());
  return true;
}
export function duplicateShape(editor) { const f = findShape(editor); if (f) editor.view.dispatch(editor.state.tr.insert(f.pos + f.node.nodeSize, f.node)); }
export function deleteShape(editor) { const f = findShape(editor); if (f) editor.view.dispatch(editor.state.tr.delete(f.pos, f.pos + f.node.nodeSize)); }

/** Inserts a text shape after the current paragraph and selects its placeholder text so you can type straight away. */
export function insertShape(editor, preset) {
  const attrs = { ...SHAPE_DEFAULTS, ...preset.attrs };
  const text = preset.text || 'Type here';
  const { $from } = editor.state.selection;
  const empty = $from.parent.isTextblock && $from.parent.content.size === 0;
  const pos = empty ? $from.before() : ($from.parent.isTextblock ? $from.after() : $from.pos);
  const node = { type: 'shapeBox', attrs, content: [{ type: 'paragraph', content: [{ type: 'text', text }] }] };
  editor.chain().focus().insertContentAt(empty ? { from: $from.before(), to: $from.after() } : pos, node).setTextSelection({ from: pos + 2, to: pos + 2 + text.length }).run();
}
